package com.lynda.javatraining.db;

public class DBUtil {

//	private static final String USERNAME = "dbuser";
//	private static final String PASSWORD = "dbpassword";
//	private static final String H_CONN_STRING =
//			"jdbc:hsqldb:data/explorecalifornia";
//	private static final String M_CONN_STRING =
//			"jdbc:mysql://localhost/explorecalifornia";

}
