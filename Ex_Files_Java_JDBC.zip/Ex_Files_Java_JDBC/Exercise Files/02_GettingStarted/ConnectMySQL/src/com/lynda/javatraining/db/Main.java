package com.lynda.javatraining.db;

public class Main {

//	private static final String USERNAME = "dbuser";
//	private static final String PASSWORD = "dbpassword";
//	private static final String CONN_STRING =
//			"jdbc:mysql://localhost/explorecalifornia";
	
	public static void main(String[] args) {
		
		
	}

}
