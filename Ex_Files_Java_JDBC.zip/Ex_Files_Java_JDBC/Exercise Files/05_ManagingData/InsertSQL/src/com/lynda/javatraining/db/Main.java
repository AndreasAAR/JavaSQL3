package com.lynda.javatraining.db;

import com.lynda.javatraining.db.tables.AdminManager;

public class Main {

	public static void main(String[] args) throws Exception {

		AdminManager.displayAllRows();
					
	}

}
